<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Core\Configure;
use Cake\Mailer\Email;

class ContactController extends AppController
{

    public function index()
    {

        $name = '';
        $phone = '';
        $email = '';
        $subject = '';
        $message = '';

        if ($this->request->is(['POST'])) {
            $name = isset($this->request->data['name']) ?
                trim($this->request->data['name']) : '';
            $phone = isset($this->request->data['phone']) ?
                trim($this->request->data['phone']) : '';
            $email = isset($this->request->data['email']) ?
                trim($this->request->data['email']) : '';
            $subject = isset($this->request->data['subject']) ?
                trim($this->request->data['subject']) : '';
            $message = isset($this->request->data['message']) ?
                trim($this->request->data['message']) : '';

            $errors = array();

            if (!isset($name[2])) {
                array_push($errors, 'Enter your name');
            }

            if (!isset($message[9])) {
                array_push($errors, 'Message content is required');
            }

            if (!isset($phone[0]) && !isset($email[0])) {
                array_push($errors, 'Either your phone number or email');
            }

            if (isset($phone[0])
                && (!ctype_digit($phone) || !isset($phone[0]) )) {
                array_push($errors, 'The phone number entered is invalid');
            }

            if (isset($email[0])
                && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                array_push($errors, 'The email entered is invalid');
            }

            if (isset($errors[0])) {
                $this->set(compact('errors'));
            } else {
                $orgData = Configure::read('school_info');

                $senderEmail = $email != ''
                    ? $email : 'noreply@' . $_SERVER['HTTP_HOST'];

                $sbjAttach = (isset($subject[0]) ? ": {$subject}" : '');
                $sendMailer = new Email();

                $sendMailer->from(array($senderEmail => $name))
                    ->emailFormat('html')
                    ->to($orgData['mailbox'])
                    ->subject('Website message' . $sbjAttach)

                    ->send($message);

                //Response to sender
                $responseMailer = new Email();
                $response = 'Dear '. $name . ',<br />'
                          . '<p>Your message was received and we will contact you as soon as possible</p>'
                          .  '<p>The management<p>'
                          .  '<p><strong>' . $orgData['name'] . '</strong></p>';

                if ($email != '') {

                    $responseMailer->from(array($orgData['contacts']['mailbox'] => $orgData['short_name']))
                          ->to($email)
                          ->emailFormat('html')
                          ->subject('Your message has been received')
                          ->send($response);
                }

                $this->set('message_sent', true);
            }

        }

        $this->set(compact('name', 'phone', 'email', 'subject', 'message'));
    }
}
